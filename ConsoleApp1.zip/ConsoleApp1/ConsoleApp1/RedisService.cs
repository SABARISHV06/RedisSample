﻿
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Enterprise.Search.Common.Service
{
    public class RedisService
    {
        private static IDatabase cache = null;

        public RedisService(string connStr)
        {
            if (!string.IsNullOrEmpty(connStr))
            {
                if (cache == null)
                {
                    Redis.InitializeConnectionString(connStr);
                    // Connection refers to a property that returns a ConnectionMultiplexer
                    cache = Redis.Connection.GetDatabase();
                }
            }
        }

        public async Task<string> GetStringAsync(string key)
        {
            try
            {
                key = key.Replace(" ","");
                return await cache.StringGetAsync(key);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public async Task<bool> StringSetAsync(string key, string value, int minutes)
        {
            try
            {
                key = key.Replace(" ", "");
                return await cache.StringSetAsync(key, value, new TimeSpan(0, minutes, 0));
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public async Task<string> TestGetStringAsync(string key)
        {
            try
            {
                key = key.Replace(" ", "");
                return await cache.StringGetAsync(key);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<bool> TestStringSetAsync(string key, string value, int minutes)
        {
            try
            {
                key = key.Replace(" ", "");
                return await cache.StringSetAsync(key, value, new TimeSpan(0, minutes, 0));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
