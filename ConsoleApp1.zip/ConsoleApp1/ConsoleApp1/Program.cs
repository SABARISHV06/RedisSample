﻿using Enterprise.Search.Common.Service;
using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            var connStr = "";
            RedisService redis = new RedisService(connStr);
            var cacheKeyWord = "testredis";
            Console.WriteLine("testredis started");

            var responseCache = redis.TestStringSetAsync(cacheKeyWord, "testword", 30).GetAwaiter().GetResult();
            Console.WriteLine("testredis set done");
            var cacheResult = redis.TestGetStringAsync(cacheKeyWord).GetAwaiter().GetResult();

            Console.WriteLine(cacheResult);
            Console.ReadKey();
        }
    }
}
